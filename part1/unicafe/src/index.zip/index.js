import React, { useState } from 'react';
import ReactDOM from 'react-dom';

const Header = ({title}) => {
  return (
    <>
      <h1>{title}</h1>
    </>
  )
}

const Button = ({handleClick, text}) => {
  return (
    <button onClick={handleClick}>
      {text}
    </button>
  )
}

const Stat = ({text, number}) => {
  if (text === 'positive')
    return (
      <div>
        {text} {number} %
      </div>
    )
  return (
    <div>
      {text} {number}
    </div>
  )
}

const App = () => {
  // save clicks of each button to own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  const [stats, setStats] = useState({
    average: 0, total: 0, positive: 0
  })
  
  const statsCalc = () => {
    const newStats = {
      average: (good - bad) / (good + bad + neutral),
      total: good + bad + neutral,
      positive: good * 100 / (good + bad + neutral)
    }
    setStats(stats => newStats)
  }
  
  const goodClick = () => {
    setGood(good + 1)
    statsCalc()
  }
  const neutralClick = () => {
    setNeutral(neutral + 1)
    statsCalc()
  }
  const badClick = () => {
    setBad(bad + 1)
    statsCalc()
    console.log("Rendering...", stats)
  }
  

  return (
    <div>
      <Header title='Give feedback' />
      <Button text='good' handleClick={goodClick} />
      <Button text='neutral' handleClick={neutralClick} />
      <Button text='bad' handleClick={badClick} />
      <Header title='Stats' />
      <Stat text='good' number={good} />
      <Stat text='neutral' number={neutral} />
      <Stat text='bad' number={bad} />
      <Stat text='all' number={stats.total} />
      <Stat text='average' number={stats.average} />
      <Stat text='positive' number={stats.positive} />

    </div>
  )
}

ReactDOM.render(<App />,
  document.getElementById('root')
  )